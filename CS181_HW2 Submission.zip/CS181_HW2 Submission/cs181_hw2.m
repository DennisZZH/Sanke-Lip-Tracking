%Author: Zihao Zhang
%Date: 1.29.2019

% template2 for liptracking2, template3 for liptracking3, template4 for liptracking4

templates = load('Template.mat');
xy = templates.template2;         % !!please adjust template number here!!
X0 = xy';

alpha = 0.1;
beta = 1;
lambda = 0.01;

e = [ 2*alpha+6*beta -alpha-4*beta beta 0 0 0 0 0 0 0 beta -alpha-4*beta];

for i = 0:11
    entry = circshift(e,i);
    A(i+1,:) = entry;
end

srcDir=uigetdir('Choose source directory.'); %choose the folder
cd(srcDir);
allnames=struct2cell(dir('*.jpg')); 
[k,len]=size(allnames);

for i = 1 : len
    
    X = X0;
    
    name=allnames{1,i};
    I = imread(name);
    
    if size(I,3) == 3
        imageGray = rgb2gray(I);
    end
    
   mask = fspecial('log',[10 10], 0.8);
   S = filter2(mask, imageGray);
    
   [Ix,Iy] = gradient(S);
   [dIxdx, dIxdy] = gradient(Ix);
   [dIydx, dIydy] = gradient(Iy);
    
    for z = 1:100
       
        for j = 1:12
            B(j,1) = 2 * ( Ix( round(X(j,2) ), round( X(j,1) ) ) * dIxdx( round(X(j,2)), round(X(j,1))) + Iy( round( X(j,2) ), round( X(j,1) ) ) * dIydx( round(X(j,2)), round(X(j,1))));
            B(j,2) = 2 * ( Ix( round(X(j,2) ), round( X(j,1) ) ) * dIxdy( round(X(j,2)), round(X(j,1))) + Iy( round( X(j,2) ), round( X(j,1) ) ) * dIydy( round(X(j,2)), round(X(j,1))));
        end

        X = X - lambda * ( A * X + B);
        
        t = 1:12;
        ts = 1: 0.1: 12;
        xys = spline(t,X',ts);
        xs = xys(1,:);
        ys = xys(2,:);
        
        imshow(I);
        axis on;
        hold on;
        plot(xs, ys, 'r-'); 
        hold off;
        pause(0.0001);
        
    end  
    
end










